
NANOMAPS_VERSION={
	version: 'dev',
	revision: 'd81d3503befd934bdb369f94f84cf42da2ab014d',
	branch: 'master',
	origin: 'git@github.com:SpatialInteractive/nanomaps-js.git',
	time: 'Mon Jul 11 16:04:00 PDT 2011',
	builder: 'stella@rhea'
};

