
NANOMAPS_VERSION={
	version: '0.2.3',
	revision: 'd81d3503befd934bdb369f94f84cf42da2ab014d',
	branch: 'master',
	origin: 'git@github.com:SpatialInteractive/nanomaps-js.git',
	time: 'Mon Jul 11 16:05:27 PDT 2011',
	builder: 'stella@rhea'
};

